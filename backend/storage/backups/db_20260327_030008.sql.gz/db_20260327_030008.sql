-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: zamoritos
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arqueos_caja`
--

DROP TABLE IF EXISTS `arqueos_caja`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `arqueos_caja` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `denominaciones` json NOT NULL,
  `fondo_cambio` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_contado` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total_esperado` decimal(12,2) NOT NULL DEFAULT '0.00',
  `diferencia` decimal(12,2) NOT NULL DEFAULT '0.00',
  `observacion` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `arqueos_caja_fecha_unique` (`fecha`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arqueos_caja`
--

LOCK TABLES `arqueos_caja` WRITE;
/*!40000 ALTER TABLE `arqueos_caja` DISABLE KEYS */;
/*!40000 ALTER TABLE `arqueos_caja` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` bigint unsigned DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tags` json DEFAULT NULL,
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorias_nombre_parent_id_unique` (`nombre`,`parent_id`),
  KEY `categorias_parent_id_foreign` (`parent_id`),
  CONSTRAINT `categorias_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,NULL,'Alimento Perros','Alimentos secos y balanceados para perros de todas las razas y etapas de vida.','[\"perro\", \"alimento\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(2,NULL,'Alimento Gatos','Alimentos secos y balanceados para gatos de interior y exterior.','[\"gato\", \"alimento\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(3,NULL,'Alimento Húmedo y Snacks','Latas, sobres, premios y snacks para perros y gatos.','[\"perro\", \"gato\", \"alimento\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(4,NULL,'Alimento Aves y Granja','Alimentos para aves domésticas, gallinas, patos y animales de granja.','[\"ave\", \"granja\", \"alimento\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(5,NULL,'Antiparasitarios','Antipulgas, antigarrapatas, desparasitantes internos y externos.','[\"todos\", \"parasitos\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(6,NULL,'Medicamentos','Suplementos, vitaminas, antibióticos y medicamentos de uso veterinario.','[\"todos\", \"medicamento\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(7,NULL,'Arena Sanitaria','Arenas aglomerantes, biodegradables y perfumadas para areneros de gatos.','[\"gato\", \"sanitario\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(8,NULL,'Bandejas y Accesorios Sanitarios','Bandejas, puertas batientes y accesorios para el arenero del gato.','[\"gato\", \"sanitario\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(9,NULL,'Collares','Collares de identificación, antipulgas y paseo para perros y gatos.','[\"perro\", \"gato\", \"paseo\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(10,NULL,'Correas y Arneses','Correas fijas, extensibles y arneses para el paseo del perro.','[\"perro\", \"paseo\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(11,NULL,'Juguetes','Juguetes interactivos, pelotas y mordedores para perros y gatos.','[\"perro\", \"gato\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(12,NULL,'Comederos y Bebederos','Platos, comederos automáticos, fuentes y bebederos para mascotas.','[\"todos\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(13,NULL,'Higiene y Belleza','Champús, acondicionadores, desodorizantes y artículos de higiene.','[\"todos\", \"higiene\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(14,NULL,'Ropa para Mascotas','Ropa, abrigos, impermeables y disfraces para perros y gatos.','[\"perro\", \"gato\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(15,NULL,'Camas y Descanso','Camas, colchonetas, mantas y hamacas para el descanso de las mascotas.','[\"perro\", \"gato\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(16,NULL,'Peines y Grooming','Cepillos, peines, tijeras, maquinas de cortar y artículos de grooming profesional.','[\"todos\", \"higiene\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(17,NULL,'Artículos del Hogar y Jardín','Productos de limpieza, ambientadores y artículos para el hogar y jardín.','[\"todos\", \"hogar\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(18,NULL,'Control de Plagas','Raticidas, insecticidas, cebos y productos para el control de plagas del hogar.','[\"todos\", \"parasitos\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(19,NULL,'Transporte','Bolsos, cajas de transporte, jaulas y transportadoras para mascotas.','[\"todos\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(20,NULL,'Rascadores','Rascadores, postes sisal, torres y centros de actividad para gatos.','[\"gato\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(21,NULL,'Accesorios Varios','Otros accesorios, artículos y novedades para mascotas.','[\"todos\", \"accesorio\"]',NULL,'2026-03-27 04:12:54','2026-03-27 04:12:54');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `combo_items`
--

DROP TABLE IF EXISTS `combo_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combo_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `combo_producto_id` bigint unsigned NOT NULL,
  `componente_producto_id` bigint unsigned NOT NULL,
  `cantidad` decimal(10,3) NOT NULL DEFAULT '1.000',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `combo_items_combo_producto_id_componente_producto_id_unique` (`combo_producto_id`,`componente_producto_id`),
  KEY `combo_items_componente_producto_id_foreign` (`componente_producto_id`),
  CONSTRAINT `combo_items_combo_producto_id_foreign` FOREIGN KEY (`combo_producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE,
  CONSTRAINT `combo_items_componente_producto_id_foreign` FOREIGN KEY (`componente_producto_id`) REFERENCES `productos` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `combo_items`
--

LOCK TABLES `combo_items` WRITE;
/*!40000 ALTER TABLE `combo_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `combo_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compras`
--

DROP TABLE IF EXISTS `compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `compras` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `proveedor_id` bigint unsigned DEFAULT NULL,
  `factura` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT '0.00',
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota` text COLLATE utf8mb4_unicode_ci,
  `tipo_pago` enum('contado','diferido') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'contado',
  `dias_plazo` smallint unsigned NOT NULL DEFAULT '0',
  `fecha_vencimiento` date DEFAULT NULL,
  `estado_pago` enum('pagado','pendiente','parcial') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pendiente',
  `monto_pagado` decimal(12,2) NOT NULL DEFAULT '0.00',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `compras_proveedor_id_foreign` (`proveedor_id`),
  CONSTRAINT `compras_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compras`
--

LOCK TABLES `compras` WRITE;
/*!40000 ALTER TABLE `compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_compras`
--

DROP TABLE IF EXISTS `detalle_compras`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_compras` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `compra_id` bigint unsigned NOT NULL,
  `producto_id` bigint unsigned NOT NULL,
  `cantidad` decimal(10,3) NOT NULL,
  `precio_compra` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `detalle_compras_compra_id_foreign` (`compra_id`),
  KEY `detalle_compras_producto_id_foreign` (`producto_id`),
  CONSTRAINT `detalle_compras_compra_id_foreign` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`) ON DELETE CASCADE,
  CONSTRAINT `detalle_compras_producto_id_foreign` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_compras`
--

LOCK TABLES `detalle_compras` WRITE;
/*!40000 ALTER TABLE `detalle_compras` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_compras` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_ventas`
--

DROP TABLE IF EXISTS `detalle_ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_ventas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `venta_id` bigint unsigned NOT NULL,
  `producto_id` bigint unsigned NOT NULL,
  `cantidad` decimal(10,3) NOT NULL,
  `precio_unitario` decimal(12,2) NOT NULL,
  `descuento` decimal(12,2) NOT NULL DEFAULT '0.00',
  `subtotal` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `detalle_ventas_venta_id_foreign` (`venta_id`),
  KEY `detalle_ventas_producto_id_foreign` (`producto_id`),
  CONSTRAINT `detalle_ventas_producto_id_foreign` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `detalle_ventas_venta_id_foreign` FOREIGN KEY (`venta_id`) REFERENCES `ventas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_ventas`
--

LOCK TABLES `detalle_ventas` WRITE;
/*!40000 ALTER TABLE `detalle_ventas` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalle_ventas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_reserved_at_available_at_index` (`queue`,`reserved_at`,`available_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lotes`
--

DROP TABLE IF EXISTS `lotes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lotes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` bigint unsigned NOT NULL,
  `compra_id` bigint unsigned DEFAULT NULL,
  `fecha_ingreso` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_vencimiento` date DEFAULT NULL,
  `cantidad` decimal(10,3) NOT NULL,
  `cantidad_restante` decimal(10,3) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lotes_producto_id_foreign` (`producto_id`),
  KEY `lotes_compra_id_foreign` (`compra_id`),
  CONSTRAINT `lotes_compra_id_foreign` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`) ON DELETE SET NULL,
  CONSTRAINT `lotes_producto_id_foreign` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lotes`
--

LOCK TABLES `lotes` WRITE;
/*!40000 ALTER TABLE `lotes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lotes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marcas`
--

DROP TABLE IF EXISTS `marcas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marcas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `marcas_nombre_unique` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marcas`
--

LOCK TABLES `marcas` WRITE;
/*!40000 ALTER TABLE `marcas` DISABLE KEYS */;
INSERT INTO `marcas` VALUES (1,'PATE PRIMOCAO','2026-03-27 04:12:54','2026-03-27 04:12:54'),(2,'BIRBO','2026-03-27 04:12:54','2026-03-27 04:12:54'),(3,'FELIX','2026-03-27 04:12:54','2026-03-27 04:12:54'),(4,'VORAZ','2026-03-27 04:12:54','2026-03-27 04:12:54'),(5,'NERO','2026-03-27 04:12:54','2026-03-27 04:12:54'),(6,'RI-MART','2026-03-27 04:12:54','2026-03-27 04:12:54'),(7,'EXCELLENT','2026-03-27 04:12:54','2026-03-27 04:12:54'),(8,'MARCE-SELECT','2026-03-27 04:12:54','2026-03-27 04:12:54'),(9,'PREVICOX','2026-03-27 04:12:54','2026-03-27 04:12:54'),(10,'DOMINAL','2026-03-27 04:12:54','2026-03-27 04:12:54'),(11,'CANGO','2026-03-27 04:12:54','2026-03-27 04:12:54'),(12,'ORIGENS','2026-03-27 04:12:54','2026-03-27 04:12:54'),(13,'MOLINO STA. ROSA','2026-03-27 04:12:54','2026-03-27 04:12:54'),(14,'DOGUI','2026-03-27 04:12:54','2026-03-27 04:12:54'),(15,'DOG CHOW','2026-03-27 04:12:54','2026-03-27 04:12:54'),(16,'MAX','2026-03-27 04:12:54','2026-03-27 04:12:54'),(17,'TALCOBAL','2026-03-27 04:12:54','2026-03-27 04:12:54'),(18,'VITALFLEX','2026-03-27 04:12:54','2026-03-27 04:12:54'),(19,'STORM','2026-03-27 04:12:54','2026-03-27 04:12:54'),(20,'KONGO','2026-03-27 04:12:54','2026-03-27 04:12:54'),(21,'THE GOLDEN CHOICE','2026-03-27 04:12:54','2026-03-27 04:12:54'),(22,'VETYS','2026-03-27 04:12:54','2026-03-27 04:12:54'),(23,'MAGNUS','2026-03-27 04:12:54','2026-03-27 04:12:54'),(24,'BIOFRESH','2026-03-27 04:12:54','2026-03-27 04:12:54'),(25,'PEDIGREE','2026-03-27 04:12:54','2026-03-27 04:12:54'),(26,'ECOPET','2026-03-27 04:12:54','2026-03-27 04:12:54'),(27,'N&D','2026-03-27 04:12:54','2026-03-27 04:12:54'),(28,'PREMIUM','2026-03-27 04:12:54','2026-03-27 04:12:54'),(29,'BIO BOTANICA','2026-03-27 04:12:54','2026-03-27 04:12:54'),(30,'PAWISE','2026-03-27 04:12:54','2026-03-27 04:12:54'),(31,'DENTAL','2026-03-27 04:12:54','2026-03-27 04:12:54'),(32,'PIPICAT','2026-03-27 04:12:54','2026-03-27 04:12:54'),(33,'LAMPO','2026-03-27 04:12:54','2026-03-27 04:12:54'),(34,'DR. CARACOL','2026-03-27 04:12:54','2026-03-27 04:12:54'),(35,'CHARRUA','2026-03-27 04:12:54','2026-03-27 04:12:54'),(36,'ZAMORITOS','2026-03-27 04:12:54','2026-03-27 04:12:54'),(37,'GENERICO','2026-03-27 04:12:54','2026-03-27 04:12:54');
/*!40000 ALTER TABLE `marcas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2024_01_01_000001_create_categorias_table',1),(5,'2024_01_01_000002_create_productos_table',1),(6,'2024_01_01_000003_create_proveedores_table',1),(7,'2024_01_01_000004_create_compras_table',1),(8,'2024_01_01_000005_create_detalle_compras_table',1),(9,'2024_01_01_000006_create_lotes_table',1),(10,'2024_01_01_000007_create_movimientos_stock_table',1),(11,'2024_01_01_000008_create_ventas_table',1),(12,'2024_01_01_000009_create_detalle_ventas_table',1),(13,'2024_01_01_000010_add_fraccionado_de_to_productos',1),(14,'2024_01_01_000011_add_promo_to_productos',1),(15,'2024_01_01_000012_add_foto_to_productos',1),(16,'2024_01_01_000013_add_precio_compra_and_notificar_to_productos',1),(17,'2024_01_01_000014_add_medios_pago_to_ventas_and_notas_to_proveedores',1),(18,'2024_01_01_000015_add_foto_url_to_productos',1),(19,'2024_01_01_000016_add_nota_to_compras',1),(20,'2024_01_01_000017_add_promo_producto_and_fraccionable_to_productos',1),(21,'2024_01_01_000018_add_numero_factura_to_ventas',1),(22,'2024_01_01_000019_create_arqueos_caja_table',1),(23,'2024_01_01_000020_add_es_combo_to_productos',1),(24,'2024_01_01_000021_create_combo_items_table',1),(25,'2024_01_01_000022_add_parent_id_to_categorias',1),(26,'2024_01_01_000023_create_marcas_table',1),(27,'2024_01_01_000024_add_thumb_to_productos',1),(28,'2024_01_01_000025_add_foto_to_categorias',1),(29,'2024_01_01_000026_add_destacado_to_productos',1),(30,'2024_01_01_000027_add_pago_fields_to_compras',1),(31,'2024_01_01_000028_create_pagos_proveedores_table',1),(32,'2024_01_01_000029_fix_categorias_unique_nombre_parent',1),(33,'2024_01_01_000030_add_descripcion_tags_to_categorias',1),(34,'2024_01_01_000030_rename_foto_url_to_foto_externa_in_productos',1),(35,'2024_01_01_000031_add_modo_fraccion_to_productos',1),(36,'2024_01_01_000032_add_saldo_manual_to_proveedores',1),(37,'2024_01_01_000033_refactor_promo_tipo_in_productos',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `movimientos_stock`
--

DROP TABLE IF EXISTS `movimientos_stock`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `movimientos_stock` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `producto_id` bigint unsigned NOT NULL,
  `tipo` enum('ingreso','venta','venta_suelta','ajuste','vencimiento') COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad` decimal(10,3) NOT NULL COMMENT 'Positivo=entrada, Negativo=salida',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `referencia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'ID de compra, venta, etc.',
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `movimientos_stock_producto_id_foreign` (`producto_id`),
  CONSTRAINT `movimientos_stock_producto_id_foreign` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `movimientos_stock`
--

LOCK TABLES `movimientos_stock` WRITE;
/*!40000 ALTER TABLE `movimientos_stock` DISABLE KEYS */;
/*!40000 ALTER TABLE `movimientos_stock` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos_proveedores`
--

DROP TABLE IF EXISTS `pagos_proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos_proveedores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `proveedor_id` bigint unsigned NOT NULL,
  `compra_id` bigint unsigned DEFAULT NULL,
  `tipo` enum('pre_compra','contado','cuota','manual') COLLATE utf8mb4_unicode_ci NOT NULL,
  `monto` decimal(12,2) NOT NULL,
  `fecha` date NOT NULL,
  `medio_pago` enum('efectivo','transferencia','cheque','otro') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'efectivo',
  `referencia` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nota` text COLLATE utf8mb4_unicode_ci,
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pagos_proveedores_proveedor_id_foreign` (`proveedor_id`),
  KEY `pagos_proveedores_compra_id_foreign` (`compra_id`),
  CONSTRAINT `pagos_proveedores_compra_id_foreign` FOREIGN KEY (`compra_id`) REFERENCES `compras` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pagos_proveedores_proveedor_id_foreign` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedores` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos_proveedores`
--

LOCK TABLES `pagos_proveedores` WRITE;
/*!40000 ALTER TABLE `pagos_proveedores` DISABLE KEYS */;
/*!40000 ALTER TABLE `pagos_proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `codigo_barras` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marca` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marca_id` bigint unsigned DEFAULT NULL,
  `categoria_id` bigint unsigned DEFAULT NULL,
  `peso` decimal(10,3) DEFAULT NULL COMMENT 'Peso total del producto (ej: 22 para bolsa 22kg)',
  `unidad_medida` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unidad' COMMENT 'kg, unidad, litro, gramo',
  `precio_venta` decimal(10,2) NOT NULL,
  `precio_compra` decimal(10,2) DEFAULT NULL,
  `stock` decimal(10,3) NOT NULL DEFAULT '0.000',
  `notificar_stock_bajo` tinyint(1) NOT NULL DEFAULT '1',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `destacado` tinyint(1) NOT NULL DEFAULT '0',
  `fraccionado_de` bigint unsigned DEFAULT NULL,
  `en_promo` tinyint unsigned NOT NULL DEFAULT '0',
  `precio_promo` decimal(10,2) DEFAULT NULL,
  `promo_producto_id` bigint unsigned DEFAULT NULL,
  `fraccionable` tinyint(1) NOT NULL DEFAULT '0',
  `modo_fraccion` enum('kg','unidad') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'kg',
  `foto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `foto_externa` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `productos_codigo_barras_unique` (`codigo_barras`),
  KEY `productos_categoria_id_foreign` (`categoria_id`),
  KEY `productos_fraccionado_de_foreign` (`fraccionado_de`),
  KEY `productos_promo_producto_id_foreign` (`promo_producto_id`),
  KEY `productos_marca_id_foreign` (`marca_id`),
  CONSTRAINT `productos_categoria_id_foreign` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`) ON DELETE SET NULL,
  CONSTRAINT `productos_fraccionado_de_foreign` FOREIGN KEY (`fraccionado_de`) REFERENCES `productos` (`id`) ON DELETE SET NULL,
  CONSTRAINT `productos_marca_id_foreign` FOREIGN KEY (`marca_id`) REFERENCES `marcas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `productos_promo_producto_id_foreign` FOREIGN KEY (`promo_producto_id`) REFERENCES `productos` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rut` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telefono` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contacto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notas` text COLLATE utf8mb4_unicode_ci,
  `saldo_manual` decimal(12,2) NOT NULL DEFAULT '0.00' COMMENT 'Deuda con el proveedor fuera del sistema de compras (editable manualmente)',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Nutrapet','214608160019','095353092',NULL,NULL,'Marcelo',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(2,'Nestle Del Uruguay S.A.','210000480010','097759866',NULL,NULL,'Nicolas',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(3,'Sadenir S.A.','215108900011','092510302',NULL,NULL,'Sara',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(4,'Agrofeed','216177480016','095968309',NULL,NULL,'Pablo',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(5,'Remiplat','215107690013','099647109',NULL,NULL,'Armando',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(6,'Ri-mart','214973250014','092141357',NULL,NULL,'Maxi',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(7,'Pet Care Uruguay','216740540016','095933134',NULL,NULL,'Silvana',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(8,'TECNODOT S A','216159010011','095723555',NULL,NULL,'Bruno',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(9,'Cedrilco s.a.','217300300015','093485018',NULL,NULL,'Los increibles',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54'),(10,'SERVIVET NUTRITION','218734020010','097969327',NULL,NULL,'Javier',NULL,0.00,1,'2026-03-27 04:12:54','2026-03-27 04:12:54');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ventas`
--

DROP TABLE IF EXISTS `ventas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ventas` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fecha` datetime NOT NULL,
  `tipo_pago` enum('contado','credito') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'contado',
  `medio_pago` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medios_pago` json DEFAULT NULL,
  `receptor_nombre` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `receptor_rut` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `moneda` char(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UYU',
  `subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `descuento` decimal(12,2) NOT NULL DEFAULT '0.00',
  `total` decimal(12,2) NOT NULL DEFAULT '0.00',
  `estado` enum('confirmada','anulada') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'confirmada',
  `tipo_comprobante` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numero_factura` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `kitfe_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `usuario` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `observacion` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ventas`
--

LOCK TABLES `ventas` WRITE;
/*!40000 ALTER TABLE `ventas` DISABLE KEYS */;
/*!40000 ALTER TABLE `ventas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-27  6:00:08
